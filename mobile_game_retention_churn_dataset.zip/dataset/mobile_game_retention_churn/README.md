# Mobile Game Retention and Churn Dataset Package

## Overview
This folder packages a reproducible dataset bundle for game churn analysis.
It includes both raw source files and processed model-ready features.

## Source
- Kaggle dataset: Mobile Game Retention & Churn Analysis
- URL: https://www.kaggle.com/datasets/rajatsurana979/mobile-game-retention-and-churn-analysis
- License: Apache 2.0 (as listed on Kaggle)

## Folder Structure
- raw/users.xlsx: user installation table
- raw/events.xlsx: user event log table
- processed/game_churn_features.csv: engineered user-level features with churn label
- processed/dataset_summary.csv: basic dataset statistics

## Raw Tables
### users.xlsx
- user_id: unique user identifier
- install_date: installation date

### events.xlsx
- user_id: unique user identifier
- event_date: event date
- event_type: event name (session_start in this dataset)

## Processed Table
### game_churn_features.csv
User-level rows with engineered features:
- user_id
- install_date
- weekly_login_days
- avg_play_time
- recent_spend_amount
- recent_win_rate
- social_activity
- activity_change_7d
- first_week_sessions
- first_week_active_days
- early_sessions
- late_sessions
- next_week_sessions
- churn

## Label Definition
- churn = 1 if the user has no session in days 7-13 after install
- churn = 0 otherwise

## Feature Definition Notes
- weekly_login_days: active days in first 7 days after install
- avg_play_time: first_week_sessions / 7
- recent_spend_amount: proxy = first_week_sessions * 0.02
- recent_win_rate: proxy = first_week_active_days / 7
- social_activity: proxy = sqrt(weekly_login_days * first_week_sessions)
- activity_change_7d: (late_sessions - early_sessions) / max(early_sessions, 1)

## Reproducibility
The processed dataset can be regenerated using project code in:
- game_churn_project_run.py
